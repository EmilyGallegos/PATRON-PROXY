using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real.Application
{
    public static class Session
    {
        public static bool CanSave { get; set; }
        public static bool CanGetAll { get; set; }
    }
}
